import { Canvas, useFrame } from '@react-three/fiber'
import { useEffect, useMemo, useRef } from 'react'
import * as THREE from 'three'
import land from '../data/landPoints.json'

// Rotating dotted globe with glowing atmosphere, offices and animated links.
const toVec = (lat, lon, r = 1) => {
  const phi = ((90 - lat) * Math.PI) / 180
  const th = ((lon + 180) * Math.PI) / 180
  return new THREE.Vector3(-r * Math.sin(phi) * Math.cos(th), r * Math.cos(phi), r * Math.sin(phi) * Math.sin(th))
}

const CITIES = [
  { name: 'Noida', lat: 28.5, lon: 77.4 },
  { name: 'Dubai', lat: 25.2, lon: 55.3 },
  { name: 'New York', lat: 40.7, lon: -74 },
]
const ROUTES = [[0, 1], [0, 2], [1, 2]]

function makeArc(a, b) {
  const va = toVec(a.lat, a.lon).normalize()
  const vb = toVec(b.lat, b.lon).normalize()
  const ang = va.angleTo(vb)
  const pts = []
  for (let i = 0; i <= 64; i++) {
    const t = i / 64
    const p = va.clone().multiplyScalar(Math.sin((1 - t) * ang) / Math.sin(ang))
      .add(vb.clone().multiplyScalar(Math.sin(t * ang) / Math.sin(ang)))
    p.normalize().multiplyScalar(1.01 + 0.34 * (ang / Math.PI) * Math.sin(Math.PI * t))
    pts.push(p)
  }
  return new THREE.CatmullRomCurve3(pts)
}

function dotTexture() {
  const c = document.createElement('canvas')
  c.width = c.height = 64
  const g = c.getContext('2d')
  const grad = g.createRadialGradient(32, 32, 0, 32, 32, 32)
  grad.addColorStop(0, 'rgba(255,255,255,1)')
  grad.addColorStop(0.55, 'rgba(255,255,255,1)')
  grad.addColorStop(1, 'rgba(255,255,255,0)')
  g.fillStyle = grad
  g.beginPath(); g.arc(32, 32, 32, 0, Math.PI * 2); g.fill()
  return new THREE.CanvasTexture(c)
}

const bodyMat = new THREE.ShaderMaterial({
  vertexShader: `varying vec3 vN; void main(){ vN = normalize(normalMatrix * normal); gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }`,
  fragmentShader: `varying vec3 vN; void main(){
    float rim = pow(1.0 - max(vN.z, 0.0), 2.4);
    vec3 core = vec3(0.012, 0.19, 0.40);
    vec3 edge = vec3(0.30, 0.58, 0.82);
    float light = 0.5 + 0.5 * dot(vN, normalize(vec3(-0.5, 0.6, 0.7)));
    gl_FragColor = vec4(mix(core * (0.7 + 0.5 * light), edge, rim), 1.0); }`,
})

const glowMat = new THREE.ShaderMaterial({
  vertexShader: `varying vec3 vN; void main(){ vN = normalize(normalMatrix * normal); gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }`,
  fragmentShader: `varying vec3 vN; void main(){
    float g = pow(clamp(-vN.z, 0.0, 1.0), 1.3) * 1.5;
    gl_FragColor = vec4(0.38, 0.66, 1.0, 1.0) * clamp(g, 0.0, 1.0); }`,
  side: THREE.BackSide, blending: THREE.AdditiveBlending, transparent: true, depthWrite: false,
})

function Land({ tex }) {
  const { pos, col } = useMemo(() => {
    const n = land.length / 2
    const pos = new Float32Array(n * 3)
    const col = new Float32Array(n * 3)
    const base = new THREE.Color('#d6e8f8')
    for (let i = 0; i < n; i++) {
      const v = toVec(land[i * 2], land[i * 2 + 1], 1.004)
      pos.set([v.x, v.y, v.z], i * 3)
      const k = 0.55 + Math.random() * 0.45
      col.set([base.r * k, base.g * k, base.b * k], i * 3)
    }
    return { pos, col }
  }, [])
  return (
    <points>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" array={pos} count={pos.length / 3} itemSize={3} />
        <bufferAttribute attach="attributes-color" array={col} count={col.length / 3} itemSize={3} />
      </bufferGeometry>
      <pointsMaterial size={0.026} map={tex} vertexColors transparent alphaTest={0.3} depthWrite={false} sizeAttenuation />
    </points>
  )
}

function Graticule() {
  const geo = useMemo(() => {
    const pts = []
    for (let lat = -60; lat <= 60; lat += 30) {
      for (let lon = 0; lon < 360; lon += 6) pts.push(toVec(lat, lon, 1.002), toVec(lat, lon + 6, 1.002))
    }
    for (let lon = 0; lon < 360; lon += 30) {
      for (let lat = -84; lat < 84; lat += 6) pts.push(toVec(lat, lon, 1.002), toVec(lat + 6, lon, 1.002))
    }
    return new THREE.BufferGeometry().setFromPoints(pts)
  }, [])
  return (
    <lineSegments geometry={geo}>
      <lineBasicMaterial color="#8fbbe6" transparent opacity={0.2} />
    </lineSegments>
  )
}

function Arc({ curve, offset, speed }) {
  const pulse = useRef()
  const trail = useRef()
  useFrame(({ clock }) => {
    const t = (clock.elapsedTime * speed + offset) % 1
    pulse.current.position.copy(curve.getPoint(t))
    trail.current.position.copy(curve.getPoint(Math.max(0, t - 0.03)))
  })
  return (
    <>
      <mesh>
        <tubeGeometry args={[curve, 64, 0.0035, 6, false]} />
        <meshBasicMaterial color="#cfe3f7" transparent opacity={0.55} />
      </mesh>
      <mesh ref={trail}>
        <sphereGeometry args={[0.014, 12, 12]} />
        <meshBasicMaterial color="#ffb066" transparent opacity={0.7} />
      </mesh>
      <mesh ref={pulse}>
        <sphereGeometry args={[0.024, 16, 16]} />
        <meshBasicMaterial color="#f17300" />
      </mesh>
    </>
  )
}

function Marker({ city, index }) {
  const group = useRef()
  const ring = useRef()
  const pos = useMemo(() => toVec(city.lat, city.lon, 1.012), [city])
  useEffect(() => {
    group.current.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), pos.clone().normalize())
  }, [pos])
  useFrame(({ clock }) => {
    const p = ((clock.elapsedTime * 0.5 + index * 0.33) % 1)
    ring.current.scale.setScalar(1 + p * 2.6)
    ring.current.material.opacity = (1 - p) * 0.8
  })
  return (
    <group ref={group} position={pos}>
      <mesh><sphereGeometry args={[0.03, 20, 20]} /><meshBasicMaterial color="#ffffff" /></mesh>
      <mesh><sphereGeometry args={[0.055, 20, 20]} /><meshBasicMaterial color="#f17300" transparent opacity={0.4} /></mesh>
      <mesh ref={ring}>
        <ringGeometry args={[0.05, 0.062, 40]} />
        <meshBasicMaterial color="#ffa24d" transparent side={THREE.DoubleSide} depthWrite={false} />
      </mesh>
    </group>
  )
}

function Globe() {
  const tilt = useRef()
  const spin = useRef()
  const mouse = useRef({ x: 0, y: 0 })
  const tex = useMemo(dotTexture, [])
  const curves = useMemo(() => ROUTES.map(([a, b]) => makeArc(CITIES[a], CITIES[b])), [])
  const start = useMemo(() => {
    const v = toVec(CITIES[0].lat, CITIES[0].lon)
    return -Math.atan2(v.x, v.z) + 0.25
  }, [])

  useEffect(() => {
    const move = (e) => {
      mouse.current.x = (e.clientX / window.innerWidth) * 2 - 1
      mouse.current.y = (e.clientY / window.innerHeight) * 2 - 1
    }
    window.addEventListener('mousemove', move)
    return () => window.removeEventListener('mousemove', move)
  }, [])

  useFrame((_, dt) => {
    spin.current.rotation.y += dt * (0.14 + mouse.current.x * 0.08)
    tilt.current.rotation.x = THREE.MathUtils.lerp(tilt.current.rotation.x, 0.38 + mouse.current.y * 0.18, 0.05)
  })

  return (
    <>
      <mesh scale={1.17} material={glowMat}><sphereGeometry args={[1, 64, 64]} /></mesh>
      <group ref={tilt} rotation={[0.38, 0, 0.18]}>
        <group ref={spin} rotation={[0, start, 0]}>
          <mesh material={bodyMat}><sphereGeometry args={[0.995, 96, 96]} /></mesh>
          <Graticule />
          <Land tex={tex} />
          {curves.map((c, i) => <Arc key={i} curve={c} offset={i * 0.31} speed={0.12 + i * 0.02} />)}
          {CITIES.map((c, i) => <Marker key={c.name} city={c} index={i} />)}
        </group>
      </group>
    </>
  )
}

export default function Hero3D({ className = '' }) {
  return (
    <div className={`hero3d ${className}`} aria-hidden="true">
      <Canvas dpr={[1, 2]} camera={{ position: [0, 0, 4.1], fov: 40 }} gl={{ alpha: true, antialias: true }}>
        <Globe />
      </Canvas>
    </div>
  )
}
