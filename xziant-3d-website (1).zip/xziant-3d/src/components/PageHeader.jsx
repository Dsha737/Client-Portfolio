import { Link } from 'react-router-dom'
import Hero3D from './Hero3D.jsx'

export default function PageHeader({ eyebrow, title, highlight, text }) {
  return (
    <section className="page-header">
      <Hero3D className="ph-3d" />
      <div className="container ph-inner">
        <nav className="crumbs" aria-label="Breadcrumb">
          <Link to="/">Home</Link> <span>/</span> <span>{eyebrow}</span>
        </nav>
        <h1>
          {title} <span className="hl">{highlight}</span>
        </h1>
        {text && <p className="lead">{text}</p>}
      </div>
    </section>
  )
}
