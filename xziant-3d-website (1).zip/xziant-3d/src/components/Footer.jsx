import { Link } from 'react-router-dom'
import { company, navLinks } from '../config.js'
import logo from '../assets/logo.png'

export default function Footer() {
  return (
    <footer className="footer">
      <div className="container footer-in">
        <div>
          <div className="brand light"><img className="logo" src={logo} alt="" width="40" height="40" /><span className="brand-text">{company.shortName}<small>Communication</small></span></div>
          <p>{company.description}</p>
        </div>
        <div>
          <h4>Explore</h4>
          {navLinks.map((l) => (
            <Link key={l.to} to={l.to}>{l.label}</Link>
          ))}
        </div>
        <div>
          <h4>Services</h4>
          <Link to="/services">TeleMarketing</Link>
          <Link to="/services">IT Staffing (USA)</Link>
          <Link to="/services">Education Technology</Link>
          <Link to="/services">Sales Center & Online Orders</Link>
        </div>
        <div>
          <h4>Contact</h4>
          <a href={`mailto:${company.email}`}>{company.email}</a>
          <a href={`tel:${company.phone.replace(/[^+\d]/g, '')}`}>{company.phone}</a>
          <span>{company.address}</span>
          <span>{company.hours}</span>
        </div>
      </div>
      <div className="footer-bottom">
        <div className="container legal">
          <span>© {new Date().getFullYear()} {company.legalName} All rights reserved.</span>
          <span className="legal-links">
            <Link to="/privacy">Privacy Policy</Link>
            <Link to="/careers">Careers</Link>
            <Link to="/contact">Contact</Link>
          </span>
        </div>
      </div>
    </footer>
  )
}
