import { useState } from 'react'
import { NavLink, Link } from 'react-router-dom'
import { company, navLinks } from '../config.js'
import logo from '../assets/logo.png'

export default function Navbar() {
  const [open, setOpen] = useState(false)
  return (
    <>
      <div className="topbar">
        <div className="container topbar-in">
          <span>✉ <a href={`mailto:${company.email}`}>{company.email}</a></span>
          <span>☎ <a href={`tel:${company.phone.replace(/[^+\d]/g, '')}`}>{company.phone}</a></span>
          <span className="hide-sm">⏱ {company.hours}</span>
        </div>
      </div>
      <header className="nav">
        <div className="container nav-in">
          <Link to="/" className="brand" onClick={() => setOpen(false)}>
            <img className="logo" src={logo} alt="" width="40" height="40" />
            <span className="brand-text">
              {company.shortName}
              <small>Communication</small>
            </span>
          </Link>
          <button className="burger" aria-label="Toggle menu" aria-expanded={open} onClick={() => setOpen(!open)}>
            <span /><span /><span />
          </button>
          <nav className={open ? 'links open' : 'links'}>
            {navLinks.map((l) => (
              <NavLink key={l.to} to={l.to} end={l.to === '/'} onClick={() => setOpen(false)}>
                {l.label}
              </NavLink>
            ))}
            <Link to="/contact" className="btn primary sm" onClick={() => setOpen(false)}>Get in touch</Link>
          </nav>
        </div>
      </header>
    </>
  )
}
