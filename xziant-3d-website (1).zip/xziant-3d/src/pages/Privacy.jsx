import { company } from '../config.js'
import PageHeader from '../components/PageHeader.jsx'

const sections = [
  {
    h: '1. Information we collect',
    p: [
      'We collect information you provide directly, such as your name, email address and message when you use our contact form or email us.',
      'We also collect limited technical data automatically, such as browser type, device information, pages visited and approximate location derived from IP address, to keep the site secure and improve it.',
    ],
  },
  {
    h: '2. How we use your information',
    p: [
      'We use your information to operate and maintain the website, respond to enquiries, improve the user experience, analyse usage, comply with legal obligations and, only with your consent, send marketing emails.',
    ],
  },
  {
    h: '3. Cookies and analytics',
    p: [
      'We use essential cookies to make the site work and, with your consent where required, analytics cookies to understand how visitors use it. You can control cookies through your browser settings.',
    ],
  },
  {
    h: '4. Sharing your information',
    p: [
      'We do not sell your personal information. We share it only with trusted service providers who process it on our behalf (such as hosting, email and analytics providers), when required by law, or as part of a business transfer.',
    ],
  },
  {
    h: '5. Data retention',
    p: [
      'We keep personal information only as long as needed for the purposes described here, or as required by law, and then delete or anonymise it.',
    ],
  },
  {
    h: '6. Your rights',
    p: [
      'Depending on where you live, you may have the right to access, correct, delete or export your personal data, to object to or restrict certain processing, and to withdraw consent at any time. To exercise these rights, contact us using the details below.',
    ],
  },
  {
    h: '7. Security',
    p: [
      'We use reasonable technical and organisational measures to protect your information. No method of transmission over the internet is completely secure, so we cannot guarantee absolute security.',
    ],
  },
  {
    h: '8. Children’s privacy',
    p: ['Our website is not directed to children under 13, and we do not knowingly collect their personal information.'],
  },
  {
    h: '9. International transfers',
    p: ['Your information may be processed in countries other than your own. Where required, we use appropriate safeguards for such transfers.'],
  },
  {
    h: '10. Changes to this policy',
    p: ['We may update this policy from time to time. The “last updated” date above shows when it was most recently revised.'],
  },
]

export default function Privacy() {
  return (
    <>
      <PageHeader
        eyebrow="Privacy Policy"
        title="Privacy"
        highlight="Policy"
        text={`Last updated: ${company.lastUpdated}`}
      />

      <section className="section narrow">
        <div className="panel prose">
          <p>
            This Privacy Policy explains how {company.legalName} (“we”, “us”) collects, uses and protects your information when
            you visit our website or contact us.
          </p>
          {sections.map((s) => (
            <div key={s.h}>
              <h3>{s.h}</h3>
              {s.p.map((t, i) => <p key={i} className="muted">{t}</p>)}
            </div>
          ))}
          <h3>11. Contact us</h3>
          <p className="muted">
            Questions about this policy? Email <a href={`mailto:${company.email}`}>{company.email}</a> or write to{' '}
            {company.name}, {company.address}.
          </p>
          <p className="note">
            This is a general template and not legal advice. Have it reviewed by a qualified professional to make sure it matches
            your actual data practices and local laws (GDPR, CCPA, etc.).
          </p>
        </div>
      </section>
    </>
  )
}
