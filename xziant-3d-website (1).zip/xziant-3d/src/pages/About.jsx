import { company } from '../config.js'
import PageHeader from '../components/PageHeader.jsx'
import teamPhoto from '../assets/career.jpg'
import owner from '../assets/owner.jpg'
import upendra from '../assets/upendra.jpg'
import rakesh from '../assets/rakesh.jpg'
import rishin from '../assets/rishin.jpg'

const values = [
  { icon: '◆', title: 'Accountability', text: 'We accept our individual and team responsibilities and meet our commitments. We take responsibility for our performance in all of our decisions and actions.' },
  { icon: '▲', title: 'Respect', text: 'We honor the rights and beliefs of our associates, customers, suppliers and community, and treat others with the highest degree of dignity, equality and trust.' },
  { icon: '●', title: 'Integrity', text: 'We employ the highest ethical standards, showing honesty and fairness in every action we take, and take ownership of our actions, decisions and consequences.' },
]

const team = [
  { name: 'Deepanshu Chaudhary', role: 'Director & Founder', photo: owner, pos: '72% 22%' },
  { name: 'Upendra Singh', role: 'Business Head', photo: upendra, pos: '50% 18%' },
  { name: 'Rakesh Singh', role: 'Business Head, US IT', photo: rakesh, pos: '42% 40%' },
  { name: 'Rishin Ummer', role: 'Business Head, UAE', photo: rishin, pos: '62% 28%' },
]

export default function About() {
  return (
    <>
      <PageHeader
        eyebrow="About Us"
        title="Communication solutions built on"
        highlight="trust and talent"
        text="A Noida-based business consultancy helping companies operate efficiently in a fast-changing digital world."
      />

      <section className="section">
        <div className="container split">
          <div className="split-photo">
            <img src={teamPhoto} alt="The Xziant team together" />
            <div className="badge"><strong>25 Jul 2019</strong><span>Company established</span></div>
          </div>
          <div>
            <span className="eyebrow">Our story</span>
            <h2>Led by a founder who believes in people</h2>
            <p className="muted">
              {company.legalName} was established on 25 July {company.founded} and is headquartered in Noida, India. Our work
              spans IT and non-IT staffing, automotive parts and accessories, and tech-driven educational programmes, all
              delivered with the same commitment to integrity and expertise.
            </p>
            <div className="duo">
              <div className="mini-card">
                <h3>Our vision</h3>
                <p>To become a leading outsourcing and contact centre provider for international businesses, while developing Indian talent and creating opportunities for local people.</p>
              </div>
              <div className="mini-card">
                <h3>Our mission</h3>
                <p>To help businesses go global through outsourcing solutions that improve efficiency and productivity across geographies.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="section tint">
        <div className="container">
          <div className="section-head">
            <span className="eyebrow">Corporate information</span>
            <h2>Company details</h2>
          </div>
          <div className="table-wrap">
            <table className="table kv">
              <tbody>
                <tr><th>Legal name</th><td>{company.legalName}</td></tr>
                <tr><th>Established</th><td>25 July {company.founded}</td></tr>
                <tr><th>Head office</th><td>{company.address}</td></tr>
                <tr><th>Director</th><td>Deepanshu Chaudhary, Founder</td></tr>
                <tr><th>Business lines</th><td>IT and non-IT staffing, telemarketing, sales centre and online orders, education technology, digital marketing</td></tr>
                <tr><th>Email</th><td>{company.email}</td></tr>
                <tr><th>Telephone</th><td>{company.phone}</td></tr>
                <tr><th>Office hours</th><td>{company.hours}</td></tr>
              </tbody>
            </table>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className="section-head">
            <span className="eyebrow">Xziant Communication</span>
            <h2>Core values</h2>
          </div>
          <div className="cards three">
            {values.map((v) => (
              <div key={v.title} className="card">
                <span className="icon">{v.icon}</span>
                <h3>{v.title}</h3>
                <p>{v.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className="section-head">
            <span className="eyebrow">Leadership</span>
            <h2>The people behind {company.shortName}</h2>
          </div>
          <div className="cards four">
            {team.map((m) => (
              <div key={m.name} className="person">
                <img src={m.photo} alt={m.name} style={{ objectPosition: m.pos }} />
                <div className="person-info">
                  <h3>{m.name}</h3>
                  <p>{m.role}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="band">
        <div className="container band-grid">
          <h2>Growing with our clients</h2>
          <div className="band-stats">
            <div><strong>321+</strong><span>Business trust us</span></div>
            <div><strong>256+</strong><span>Projects done</span></div>
            <div><strong>92%+</strong><span>Success rate</span></div>
            <div><strong>5Y+</strong><span>Years of experience</span></div>
          </div>
        </div>
      </section>
    </>
  )
}
