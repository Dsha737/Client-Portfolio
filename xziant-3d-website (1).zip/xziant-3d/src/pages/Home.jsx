import { Link } from 'react-router-dom'
import { company } from '../config.js'
import Hero3D from '../components/Hero3D.jsx'
import officeMan from '../assets/office-man.jpg'
import consultants from '../assets/consultants.jpg'
import bank from '../assets/bank.jpg'
import sales from '../assets/sales.jpg'

const stats = [
  { n: '321+', l: 'Business trust us' },
  { n: '256+', l: 'Projects done' },
  { n: '92%+', l: 'Success rate' },
  { n: '5Y+', l: 'Years of experience' },
]

const lines = [
  { name: 'TeleMarketing', desc: 'Outbound sales calls, survey programmes and information calls.', tag: 'Outsourcing' },
  { name: 'IT Staffing (USA)', desc: 'Candidate screening, payroll and compliance support, short- and long-term placements.', tag: 'Staffing' },
  { name: 'Education Technology', desc: 'Online courses in Data Science, Cyber Security and DevOps Engineering.', tag: 'Training' },
  { name: 'Sales Center & Online Orders', desc: 'A dedicated call centre for sales calling, ticket handling and order taking.', tag: 'Outsourcing' },
  { name: 'Digital Marketing & Lead Generation', desc: 'Campaigns that bring qualified prospects to your business.', tag: 'Marketing' },
]

const values = [
  { t: 'Accountability', d: 'We accept our individual and team responsibilities and meet our commitments. We take responsibility for our performance in all of our decisions and actions.', pts: ['Take ownership of actions, decisions and consequences', 'Admit mistakes, honor successes and learn in the process', 'Focus on solving problems rather than assigning blame'] },
  { t: 'Respect', d: 'We honor the rights and beliefs of our fellow associates, customers, shareowners, suppliers and community. We treat others with the highest degree of dignity, equality and trust.', pts: ["Show consideration for everyone's time and responsibilities", 'Listen', 'Value and encourage open and honest communication', 'Respond to requests in a timely manner'] },
  { t: 'Integrity', d: 'We employ the highest ethical standards, demonstrating honesty and fairness in every action we take.', pts: ['Lead by example', 'Keep commitments', 'Have the courage to act upon facts, not rumors', 'Build and maintain trust through candid, caring communication'] },
]

const reviews = [
  {
    name: 'Rohit Mehra', rating: 4,
    text: "I was impressed with Xziant's expertise in IT and Non-IT staffing. They provided us with highly skilled professionals who perfectly matched our requirements. Their customer service and commitment to excellence are truly commendable!",
  },
  {
    name: 'Sneha Iyer', rating: 5,
    text: 'From automotive accessories to educational programs, Xziant delivers quality and innovation in every aspect. Their tech-driven learning solutions helped me enhance my skills, making my career growth seamless. Would love to see more advanced courses!',
  },
]

const steps = [
  { t: 'Understand', d: 'We learn your goals, customers and targets.' },
  { t: 'Build the team', d: 'We select people who fit your brand and culture.' },
  { t: 'Launch', d: 'Your campaign goes live with clear processes.' },
  { t: 'Report & improve', d: 'We share results and keep refining.' },
]

export default function Home() {
  return (
    <>
      {/* Hero */}
      <section className="hero">
        <div className="container hero-grid">
          <div className="hero-copy">
            <span className="pill">{company.tagline}</span>
            <h1>Transforming industries with integrity and expertise</h1>
            <p className="lead">{company.description}</p>
            <div className="cta-row">
              <Link to="/about" className="btn primary">Learn more</Link>
              <a className="btn outline" href={`tel:${company.phone.replace(/[^+\d]/g, '')}`}>☎ {company.phone}</a>
            </div>
          </div>

          <div className="hero-visual">
            <Hero3D className="hero-globe" />
            <figure className="hero-photo-card">
              <img src={officeMan} alt="Business professional working on a laptop" />
            </figure>
          </div>
        </div>
        <div className="container hero-facts">
          <ul className="mini-stats">
            {stats.map((s) => (
              <li key={s.l}><strong>{s.n}</strong><span>{s.l}</span></li>
            ))}
          </ul>
        </div>
      </section>

      {/* About: overlapping photos, as on xziant.com */}
      <section className="section">
        <div className="container about-grid">
          <div className="about-photos">
            <img className="ap-main" src={consultants} alt="Consultant meeting with a client" />
            <img className="ap-second" src={bank} alt="Consultant with a tablet" />
            <div className="ap-badge"><strong>321+</strong><span>Business trust us</span></div>
          </div>
          <div>
            <span className="eyebrow">What do you know about us?</span>
            <h2>We are business consultants dedicated to driving your success</h2>
            <p className="muted">
              Established in 2019 and headquartered in Noida, India, {company.legalName} excels in IT and non-IT staffing,
              automotive parts and accessories, and tech-driven educational programs.
            </p>
            <p className="muted">
              We are dedicated to delivering innovative and reliable communication solutions that empower businesses to thrive in
              a rapidly evolving digital landscape. With a strong focus on excellence, customer satisfaction and cutting-edge
              technology, we have established ourselves as a trusted partner for organizations seeking seamless communication and
              operational efficiency.
            </p>
            <blockquote className="pull">“Transforming Industries with Integrity and Expertise”</blockquote>
            <Link to="/about" className="btn primary">Know more →</Link>
          </div>
        </div>
      </section>

      {/* Consulting solutions */}
      <section className="section tint">
        <div className="container">
          <div className="section-head">
            <span className="eyebrow">Consulting solutions</span>
            <h2>We've got your business covered</h2>
          </div>
          <div className="table-wrap">
            <table className="table">
              <thead>
                <tr><th>Service</th><th>Scope</th><th>Category</th></tr>
              </thead>
              <tbody>
                {lines.map((l) => (
                  <tr key={l.name}>
                    <td><Link to="/services">{l.name}</Link></td>
                    <td>{l.desc}</td>
                    <td><span className="chip">{l.tag}</span></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </section>

      {/* Core values */}
      <section className="section">
        <div className="container">
          <div className="section-head">
            <span className="eyebrow">Xziant Communication</span>
            <h2>Core values</h2>
          </div>
          <div className="values">
            {values.map((v, i) => (
              <article key={v.t} className={i === 1 ? 'value dark' : 'value'}>
                <h3>{v.t}</h3>
                <p>{v.d}</p>
                <ul>{v.pts.map((p) => <li key={p}>{p}</li>)}</ul>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="section tint">
        <div className="container">
          <div className="section-head">
            <span className="eyebrow">Testimonials</span>
            <h2>See how others have benefited</h2>
          </div>
          <div className="quotes">
            {reviews.map((r) => (
              <blockquote key={r.name} className="quote">
                <div className="stars" aria-label={`${r.rating} out of 5 stars`}>
                  {'★'.repeat(r.rating)}<span className="off">{'★'.repeat(5 - r.rating)}</span>
                </div>
                <p>{r.text}</p>
                <footer>
                  <span className="avatar">{r.name.split(' ').map((w) => w[0]).join('')}</span>
                  {r.name}
                </footer>
              </blockquote>
            ))}
          </div>
        </div>
      </section>

      {/* Process */}
      <section className="section">
        <div className="container">
          <div className="section-head">
            <span className="eyebrow">Engagement model</span>
            <h2>From first conversation to measurable results</h2>
          </div>
          <ol className="steps">
            {steps.map((s, i) => (
              <li key={s.t}>
                <span className="step-n">{i + 1}</span>
                <h3>{s.t}</h3>
                <p>{s.d}</p>
              </li>
            ))}
          </ol>
        </div>
      </section>

      {/* Get in touch */}
      <section className="getin">
        <div className="container getin-grid">
          <div className="getin-photo">
            <img src={sales} alt="Xziant sales consultant" />
            <div className="addr-card">
              <h3>Our address</h3>
              <p>{company.address}</p>
              <p><a href={`mailto:${company.email}`}>✉ {company.email}</a></p>
              <p><a href={`tel:${company.phone.replace(/[^+\d]/g, '')}`}>☎ {company.phone}</a></p>
            </div>
          </div>
          <div className="getin-text">
            <span className="eyebrow">Contact us</span>
            <h2>Have questions? Get in touch</h2>
            <p>We offer unique business analysis to growth strategies designed to meet your specific needs. We respond to business enquiries Monday to Saturday.</p>
            <Link to="/contact" className="btn primary">Contact us</Link>
          </div>
        </div>
      </section>
    </>
  )
}
