import { company } from '../config.js'
import PageHeader from '../components/PageHeader.jsx'
import teamPhoto from '../assets/career.jpg'
import portrait from '../assets/shedd.jpg'
import officeMan from '../assets/office-man.jpg'

const positions = [
  {
    title: 'Telesales Division (International Process)',
    place: 'Ghaziabad',
    text: 'Sell post-paid mobile, home internet and business plans for a premium UAE telecom provider.',
  },
  {
    title: 'Business Development Executive (BDE)',
    place: 'Ghaziabad',
    text: 'A sales-focused role on our growth team. Contact us for the full job description.',
  },
]

const requirements = [
  'Fluent English and Hindi or Urdu',
  'Strong sales, persuasion and interpersonal skills',
  'Ability to update records in computer systems',
  'Any graduate degree; fresh graduates are welcome',
  'Preferred: telecom telesales or outbound call centre experience',
]

const perks = [
  { icon: '₹', t: 'Salary', d: '₹15,000 – ₹25,000 per month' },
  { icon: '★', t: 'Incentives', d: 'From ₹10,000 a month, based on sales' },
  { icon: '✦', t: 'Rewards', d: 'Top-performer schemes and bonuses' },
  { icon: '✈', t: 'Office trips', d: 'Team outings and celebrations' },
]

export default function Careers() {
  const mail = (role) =>
    `mailto:${company.email}?subject=${encodeURIComponent('Application: ' + role)}`

  return (
    <>
      <PageHeader
        eyebrow="Careers"
        title="Join the team that"
        highlight="grows with you"
        text="We welcome innovators and dreamers, in an open, collaborative workplace with equal opportunities."
      />

      <section className="section">
        <div className="container split">
          <div className="split-photo">
            <img src={teamPhoto} alt="The Xziant team gathered outdoors" />
          </div>
          <div>
            <span className="eyebrow">Life at {company.shortName}</span>
            <h2>A workplace where good work is noticed</h2>
            <p className="muted">
              Fresh graduates and experienced sales professionals alike will find coaching, clear targets and real rewards for
              results.
            </p>
            <ul className="checks">
              {requirements.map((r) => <li key={r}>{r}</li>)}
            </ul>
          </div>
        </div>
      </section>

      <section className="section tint">
        <div className="container">
          <div className="section-head">
            <span className="eyebrow">What you get</span>
            <h2>Pay and perks</h2>
          </div>
          <div className="cards four">
            {perks.map((p) => (
              <div key={p.t} className="card">
                <span className="icon">{p.icon}</span>
                <h3>{p.t}</h3>
                <p>{p.d}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="section" id="apply">
        <div className="container">
          <div className="section-head">
            <span className="eyebrow">Open positions</span>
            <h2>Find your role</h2>
          </div>
          <div className="jobs">
            {positions.map((j) => (
              <div key={j.title} className="job">
                <div>
                  <h3>{j.title}</h3>
                  <span className="tag">⌖ {j.place}</span>
                  <p className="muted">{j.text}</p>
                </div>
                <a className="btn primary" href={mail(j.title)}>Apply now</a>
              </div>
            ))}
          </div>
          <p className="muted apply-note">
            Send your CV and the role name to <a href={`mailto:${company.email}`}>{company.email}</a>.
          </p>
          <div className="gallery">
            <img src={portrait} alt="Xziant team member" style={{ objectPosition: '50% 30%' }} />
            <img src={officeMan} alt="Team member at work" />
          </div>
        </div>
      </section>
    </>
  )
}
