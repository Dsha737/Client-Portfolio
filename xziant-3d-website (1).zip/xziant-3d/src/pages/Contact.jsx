import { useState } from 'react'
import { company } from '../config.js'
import PageHeader from '../components/PageHeader.jsx'

const empty = { name: '', email: '', subject: 'New project', message: '' }

export default function Contact() {
  const [form, setForm] = useState(empty)
  const [errors, setErrors] = useState({})
  const [sent, setSent] = useState(false)

  const update = (e) => setForm({ ...form, [e.target.name]: e.target.value })

  const validate = () => {
    const err = {}
    if (!form.name.trim()) err.name = 'Please enter your name.'
    if (!/^\S+@\S+\.\S+$/.test(form.email)) err.email = 'Please enter a valid email.'
    if (form.message.trim().length < 10) err.message = 'Tell us a little more (10+ characters).'
    return err
  }

  const submit = (e) => {
    e.preventDefault()
    const err = validate()
    setErrors(err)
    if (Object.keys(err).length) return
    // Demo behaviour: opens the visitor's email client. Replace with your API call / form service.
    const body = encodeURIComponent(`${form.message}\n\n— ${form.name} (${form.email})`)
    window.location.href = `mailto:${company.email}?subject=${encodeURIComponent(form.subject)}&body=${body}`
    setSent(true)
    setForm(empty)
  }

  return (
    <>
      <PageHeader
        eyebrow="Contact Us"
        title="We'd love to"
        highlight="hear from you"
        text="We are passionate about driving success for businesses. Share a few details and we'll get back to you."
      />

      <section className="section">
        <div className="container contact-grid">
          <form className="panel form" onSubmit={submit} noValidate>
            <h2>Send us a message</h2>
            <div className="row">
              <label>
                Name
                <input name="name" value={form.name} onChange={update} placeholder="Your full name" />
                {errors.name && <small className="err">{errors.name}</small>}
              </label>
              <label>
                Email
                <input name="email" type="email" value={form.email} onChange={update} placeholder="you@company.com" />
                {errors.email && <small className="err">{errors.email}</small>}
              </label>
            </div>
            <label>
              Topic
              <select name="subject" value={form.subject} onChange={update}>
                <option>New project</option>
                <option>TeleMarketing</option>
                <option>IT Staffing (USA)</option>
                <option>Education Technology</option>
                <option>Sales Center & Online Orders</option>
                <option>Careers</option>
                <option>Something else</option>
              </select>
            </label>
            <label>
              Message
              <textarea name="message" rows="5" value={form.message} onChange={update} placeholder="Tell us about your requirements…" />
              {errors.message && <small className="err">{errors.message}</small>}
            </label>
            <button className="btn primary" type="submit">Send message</button>
            {sent && <p className="ok">Thanks! Your email app should open with your message ready to send.</p>}
          </form>

          <aside className="info-stack">
            <div className="info-card">
              <span className="icon">✉</span>
              <div><small>Email</small><a href={`mailto:${company.email}`}>{company.email}</a></div>
            </div>
            <div className="info-card">
              <span className="icon">☎</span>
              <div><small>Telephone</small><a href={`tel:${company.phone.replace(/[^+\d]/g, '')}`}>{company.phone}</a></div>
            </div>
            <div className="info-card">
              <span className="icon">⌖</span>
              <div>
                <small>Head office</small>
                <p>{company.address}</p>
                <a href={company.mapUrl} target="_blank" rel="noreferrer">View on Google Maps ↗</a>
              </div>
            </div>
            <div className="info-card">
              <span className="icon">⏱</span>
              <div><small>Office hours</small><p>{company.hours}</p></div>
            </div>
          </aside>
        </div>
      </section>
    </>
  )
}
