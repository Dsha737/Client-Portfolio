import { Link } from 'react-router-dom'
import PageHeader from '../components/PageHeader.jsx'
import bank from '../assets/bank.jpg'
import consultants from '../assets/consultants.jpg'
import officeMan from '../assets/office-man.jpg'
import sales from '../assets/sales.jpg'

const services = [
  {
    icon: '☎',
    title: 'TeleMarketing',
    text: 'Outbound calling campaigns tailored to your business goals, run by skilled and responsive callers.',
    points: ['Sales calls to grow revenue', 'Survey scripting and data collection', 'Information and update calls'],
    photo: consultants,
    alt: 'Consultant presenting to a client',
    pos: '50% 20%',
  },
  {
    icon: '⬡',
    title: 'IT Staffing (USA)',
    text: 'IT talent for US companies, with the admin handled for you.',
    points: ['Candidate screening and interviews', 'Payroll and compliance support', 'Short- and long-term placements', 'Flexible pricing for your budget'],
    photo: officeMan,
    alt: 'IT professional working on a laptop',
    pos: '50% 50%',
  },
  {
    icon: '✦',
    title: 'Education Technology',
    text: 'Online courses that build practical skills for in-demand tech careers, for beginners and professionals.',
    points: ['Data Science', 'Cyber Security', 'DevOps Engineering', 'Hands-on labs and real-world projects'],
  },
  {
    icon: '▣',
    title: 'Sales Center & Online Orders',
    text: 'A dedicated call centre that runs your campaigns without your team being on site.',
    points: ['Sales calling and order taking', 'Ticket handling', 'Team chosen to fit your brand and culture'],
    photo: sales,
    alt: 'Sales consultant in a suit holding a laptop',
    pos: '55% 25%',
  },
  {
    icon: '◈',
    title: 'Digital Marketing & Lead Generation',
    text: 'Campaigns that bring qualified prospects to your business.',
    points: ['Lead generation', 'Digital campaigns', 'Pipeline support for sales teams'],
    photo: bank,
    alt: 'Marketing consultant with a tablet',
    pos: '50% 25%',
  },
]

export default function Services() {
  return (
    <>
      <PageHeader
        eyebrow="Services"
        title="Solutions designed to meet"
        highlight="your specific needs"
        text="From staffing and calling to training and lead generation, one partner for the whole journey."
      />

      <section className="section">
        <div className="container zig">
          {services.map((s, i) => (
            <article key={s.title} className={i % 2 ? 'zig-row flip' : 'zig-row'}>
              <div className="zig-visual">
                {s.photo ? (
                  <img src={s.photo} alt={s.alt} style={{ objectPosition: s.pos }} />
                ) : (
                  <div className="tile"><span>{s.icon}</span></div>
                )}
              </div>
              <div className="zig-text">
                <span className="icon">{s.icon}</span>
                <h2>{s.title}</h2>
                <p className="muted">{s.text}</p>
                <ul className="checks">
                  {s.points.map((p) => <li key={p}>{p}</li>)}
                </ul>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className="cta">
            <div>
              <h2>Not sure what you need?</h2>
              <p>Tell us about your business and we'll recommend the right service.</p>
            </div>
            <Link to="/contact" className="btn light">Contact us</Link>
          </div>
        </div>
      </section>
    </>
  )
}
