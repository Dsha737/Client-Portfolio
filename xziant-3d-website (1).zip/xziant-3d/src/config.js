// Edit this file to rebrand the whole site.
// Details below were taken from https://xziant.com/
export const company = {
  name: 'Xziant Communication',
  shortName: 'Xziant',
  legalName: 'Xziant Communications Pvt. Ltd.',
  tagline: 'Passion for the Communities',
  headline: 'Transforming Industries with Integrity and Expertise',
  description:
    'Xziant Communications is a Noida-based business consultancy delivering IT and non-IT staffing, telemarketing, sales and order centres, and tech-driven education.',
  email: 'support@xziant.com',
  phone: '+91 84486 10952',
  address: '202, Sector 63 Rd, A Block, Sector 63, Noida, Uttar Pradesh 201301, India',
  hours: 'Monday – Saturday',
  mapUrl: 'https://www.google.com/maps/search/?api=1&query=Xziant+Communication+Pvt+Ltd+Sector+63+Noida',
  website: 'https://xziant.com',
  founded: 2019,
  lastUpdated: 'October 24, 2026',
}

export const navLinks = [
  { to: '/', label: 'Home' },
  { to: '/about', label: 'About Us' },
  { to: '/services', label: 'Services' },
  { to: '/careers', label: 'Careers' },
  { to: '/contact', label: 'Contact Us' },
  { to: '/privacy', label: 'Privacy Policy' },
]
