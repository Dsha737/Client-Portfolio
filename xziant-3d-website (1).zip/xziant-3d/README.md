# Xziant Communication Website (React + Three.js)

Pages: Home, About Us, Services, Careers, Contact Us, Privacy Policy.

## Run in VS Code
1. Install Node.js 18 or newer from https://nodejs.org (LTS).
2. Unzip the project and open the `xziant-3d` folder in VS Code (File > Open Folder).
3. Open the terminal (Terminal > New Terminal) and run:
   ```
   npm install
   npm run dev
   ```
4. Open http://localhost:5173 in your browser.

## Build for hosting
```
npm run build      # output goes to /dist
npm run preview    # test the production build locally
```
Upload the contents of `dist` to your host. Set the host to send every path to `index.html`, otherwise refreshing on `/about` shows an error.

## Where to edit
- Company name, contact details, nav links: `src/config.js`
- Page content: `src/pages/*.jsx`
- Photos: `src/assets/` (replace files, keep the names, or update the imports)
- Globe (cities, speed, colours): `src/components/Hero3D.jsx`
- Colours, fonts, spacing: `src/styles.css` (the variables at the top)

## Notes
- The contact form opens the visitor's email app (demo). Replace `submit` in `src/pages/Contact.jsx` with your API or a form service.
- The Privacy Policy is a general template, not legal advice. Have it reviewed before publishing.
